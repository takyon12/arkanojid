#include "generator.h"

#include "brick.h"


bool Generator::Update(Scene &scene, float dt) {
  // Accumulate time
  time += dt;

  // Add object to scene when time reaches certain level
  if (time > .1 && alive < 15) {
    alive++;
    auto obj = BrickPtr(new Brick());
    obj->position = this->position+offset;
    offset.y-=1.5f;
    if(alive>0 && alive % 5 == 0) {
      offset.x+=Rand(-4.0f,-4.5f);      //posuva sa koordinata X

      offset.y=0.0f;
    }
    scene.objects.push_back(obj);
    time = 0;

  }

  return true;
}

void Generator::iDied() {
  alive--;
}

void Generator::Render(Scene &scene) {
  // Generator will not be rendered
}

Generator::~Generator() {
}

Generator::Generator() {
  time = 0;
  offset = glm::vec3(0.0f, 0.0f, 0.0f);
}
