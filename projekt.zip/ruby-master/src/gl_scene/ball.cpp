
#include "ball.h"
#include "object_frag.h"
#include "object_vert.h"

Ball::Ball() {

    // Set random scale speed and rotation
    scale *= 0.5f;//Rand(1.0f, 3.0f);
    speed = glm::vec3(Rand(-10.0f, 10.0f), Rand(-10.0f, -20.0f), 0.0f);
    rotation = glm::vec3(Rand(-PI, PI), Rand(-PI, PI), Rand(-PI, PI));
    rotMomentum = glm::vec3(Rand(-PI, PI), Rand(-PI, PI), Rand(-PI, PI));

    // Initialize static resources if needed
    if (!shader) shader = ShaderPtr(new Shader{object_vert, object_frag});
    //if (!texture) texture = TexturePtr(new Texture{"2color.rgb", 500, 288});
    if (!texture) texture = TexturePtr(new Texture{"tball1.rgb", 500, 288});
    if (!mesh) mesh = MeshPtr(new Mesh{shader, "lopticka.obj"});
}

Ball::~Ball() {
}

bool Ball::Update(Scene &scene, float dt) {
    // Count time alive
    age += dt;

    // Animate position according to time
    if(position.y + speed.y*dt > 8.2f) {
        speed.y*=-1.0f;
        position += speed * dt;
    }
    else if(std::abs(position.x + speed.x*dt) > 8.2f) {
        speed.x*=-0.5f;  //-1.0f
        position += speed * dt;
    }
    else {
        position += speed * dt;
    }

    // Rotate the object
    rotation += rotMomentum * dt;

    // Delete when alive longer than 10s or out of visibility
    if (position.y < -10) return false;

    // Generate modelMatrix from position, rotation and scale
    GenerateModelMatrix();

    return true;
}

void Ball::Render(Scene &scene) {
    shader->Use();

    // use camera
    shader->SetMatrix(scene.camera->projectionMatrix, "ProjectionMatrix");
    shader->SetMatrix(scene.camera->viewMatrix, "ViewMatrix");
    shader->SetVector(scene.camera->position, "ViewPosition");

    // render mesh
    shader->SetMatrix(modelMatrix, "ModelMatrix");
    shader->SetTexture(texture, "Texture");
    mesh->Render();
}


// shared resources
MeshPtr Ball::mesh;
ShaderPtr Ball::shader;
TexturePtr Ball::texture;
