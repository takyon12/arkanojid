#include "player.h"
#include "scene.h"
#include "asteroid.h"
#include "projectile.h"
#include "explosion.h"

#include "object_frag.h"
#include "object_vert.h"
#include "ball.h"

#include <GLFW/glfw3.h>
#include <iostream>
#include <cmath>


Player::Player() {
  // Reset fire delay
  fireDelay = 0;
  // Set the rate of fire
  fireRate = 0.3f;
  // Fire offset;
  fireOffset = glm::vec3(0.7f,0.0f,0.0f);

  // Scale the default model
  scale *= 0.5f;
//  rotation.z=PI/2.2f;
  speed=0;

  // Initialize static resources if needed
  if (!shader) shader = ShaderPtr(new Shader{object_vert, object_frag});
  //if (!texture) texture = TexturePtr(new Texture{"batman.RGB", 960, 540});
  if (!texture) texture = TexturePtr(new Texture{"yellow.RGB", 512, 512});
  if (!mesh) mesh = MeshPtr(new Mesh{shader, "tehlicka.obj"});
}

Player::~Player() {
}

bool Player::Update(Scene &scene, float dt) {
  // Fire delay increment
  fireDelay += dt;
  glm::vec4 worldposP = scene.camera->viewMatrix * modelMatrix * glm::vec4(position, 1.0);

  // Hit detection
  for ( auto obj : scene.objects ) {
    // Ignore self in scene
    if (obj.get() == this)
      continue;

    // We only need to collide with asteroids, ignore other objects
    auto ball = std::dynamic_pointer_cast<Ball>(obj);
    if (!ball) continue;

    glm::vec4 worldposA = scene.camera->viewMatrix * modelMatrix * glm::vec4(ball->position, 1.0);

    if (std::abs(position.x + speed*direction - (ball->position.x+ball->speed.x*dt)) < 3.03f &&
            std::abs(position.y - (ball->position.y + ball->speed.y*dt) ) < 1.2f ) {
      // Explode
      auto explosion = ExplosionPtr(new Explosion{});
      explosion->position = position;
      explosion->scale = scale * 3.0f;
      scene.objects.push_back(explosion);
    ball->speed.y*=(-1.0f);
      float coss=cos(ball->speed.x);
      float sins=sin(ball->speed.y);
      ball->speed.x+=coss*accel*dt*5;
      ball->speed.y+=sins*accel*dt*5;
      // Die
      //return false;
    }
    if (std::abs(position.x + speed*direction - (ball->position.x+ball->speed.x*dt)) >= 3.03f &&
        std::abs(position.x + speed*direction - (ball->position.x+ball->speed.x*dt)) < 3.30f &&
            std::abs(position.y - (ball->position.y + ball->speed.y*dt) ) < 1.2f ) {
      if (std::abs(8.2f - (position.x + speed * direction) - (ball->position.x + ball->speed.x * dt)) > ball->scale.y) {
        if (direction < 0 && ball->speed.x < 0)
          ball->speed.x -= (5.0f);
        else if (direction < 0 && ball->speed.x > 0)
          ball->speed.x *= -1.5f;
        else if (direction > 0 && ball->speed.x > 0)
          ball->speed.x += 5.0f;
        else if (direction > 0 && ball->speed.x < 0)
          ball->speed.x *= -1.5f;
      }
    }

  }

  // Keyboard controls
  if(scene.keyboard[GLFW_KEY_LEFT]) {
    if(position.x < 6.0f) {
      direction=1.0f;
      position.x += accel * dt;
      if (accel < 20.0f)
        accel += 0.5f;
      speed = accel * dt;
    }
    else {
      accel = 10;
      speed = 0;
    }
    //    rotation.z = 3*PI/4.0f;
  } else if(scene.keyboard[GLFW_KEY_RIGHT]) {
    if(position.x > -6.0f) {
      direction=-1.0f;
      position.x -= accel * dt;
      speed = accel * dt;
      if (accel < 20.0f)
        accel += 0.5f;
    }
    else {
      accel = 10;
      speed = 0;
    }
//    rotation.z = PI/4.0f;
  }
    else if(scene.keyboard[GLFW_KEY_UP]) {
      worldposP = scene.camera->viewMatrix * modelMatrix * glm::vec4(position, 1.0);
      std::cout << "WorldposP.x je " << worldposP.x;
  } else {
    accel=10;
    rotation.z = PI/2.0f;
    speed=0;
  }

  // Firing projectiles
  if(scene.keyboard[GLFW_KEY_SPACE] && fireDelay > fireRate) {
    // Reset fire delay
    fireDelay = 0;
    // Invert file offset
    fireOffset = -fireOffset;

    auto projectile = ProjectilePtr(new Projectile{});
    projectile->position = position + glm::vec3(0.0f, 0.0f, 0.3f) + fireOffset;
    scene.objects.push_back(projectile);
  }

  GenerateModelMatrix();
  return true;
}

void Player::Render(Scene &scene) {
  shader->Use();

  // use camera
  shader->SetMatrix(scene.camera->projectionMatrix, "ProjectionMatrix");
  shader->SetMatrix(scene.camera->viewMatrix, "ViewMatrix");
  shader->SetVector(scene.camera->position, "ViewPosition");

  // render mesh
  shader->SetMatrix(modelMatrix, "ModelMatrix");
  shader->SetTexture(texture, "Texture");
  mesh->Render();
}

// shared resources
MeshPtr Player::mesh;
ShaderPtr Player::shader;
TexturePtr Player::texture;