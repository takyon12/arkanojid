
#include "brick.h"
#include "object_frag.h"
#include "object_vert.h"
#include "ball.h"
#include "explosion.h"


Brick::Brick() {
    // Reset the age to 0
    // age = 0;
    health=2;
    // Set random scale speed and rotation
    scale *= 0.5f;//Rand(1.0f, 3.0f);
    scale.y*=0.8f;
    scale.z*=0.5f;
   // speed = glm::vec3(Rand(-5.0f, 5.0f), Rand(-5.0f, -10.0f), 0.0f);
   // rotation = glm::vec3(Rand(-PI, PI), Rand(-PI, PI), Rand(-PI, PI));
    rotation.z = PI/2.0f;
  //  rotMomentum = glm::vec3(Rand(-PI, PI), Rand(-PI, PI), Rand(-PI, PI));

    // Initialize static resources if needed
    if (!shader) shader = ShaderPtr(new Shader{object_vert, object_frag});
    if (!texture_healthy) texture_healthy = TexturePtr(new Texture{"orange.rgb", 512, 512});
    if (!texture_halfHP) texture_halfHP = TexturePtr(new Texture{"reddish.rgb", 512, 512});
    if (!mesh) mesh = MeshPtr(new Mesh{shader, "tehlicka.obj"});
}

Brick::~Brick() {
}

bool Brick::Update(Scene &scene, float dt) {
    // Count time alive
    age += dt;

    // Animate position according to time
    if (position.y + speed.y * dt > 9) {
        speed *= -1.0f;
        position += speed * dt;
    }
    else {
        position += speed * dt;
    }

    // Rotate the object
    rotation += rotMomentum * dt;

    // Delete when alive longer than 10s or out of visibility
    if (position.y < -10 || health==0) return false;

    for (auto obj : scene.objects) {
        // Ignore self in scene
        if (obj.get() == this)
            continue;

        // We only need to collide with balls, ignore other objects
        auto ball = std::dynamic_pointer_cast<Ball>(obj);
        if (!ball) continue;
        if (glm::distance(position.x, ball->position.x) < ball->scale.x*3 &&
            glm::distance(position.y, ball->position.y) < ball->scale.y*2) {
            health--;
            ball->speed.y*=-1.0f;
            if(glm::distance(position.x, ball->position.x) > ball->scale.x*2)
                ball->speed.x*=-1.0f;

            // Explode
            auto explosion = ExplosionPtr(new Explosion{});
            explosion->position = position;
            explosion->scale = scale * 1.0f;
            scene.objects.push_back(explosion);

        }
        if(health == 0) return false;
    }

        // Generate modelMatrix from position, rotation and scale
        GenerateModelMatrix();

        return true;

}

void Brick::Render(Scene &scene) {
    shader->Use();

    // use camera
    shader->SetMatrix(scene.camera->projectionMatrix, "ProjectionMatrix");
    shader->SetMatrix(scene.camera->viewMatrix, "ViewMatrix");
    shader->SetVector(scene.camera->position, "ViewPosition");

    // render mesh
    shader->SetMatrix(modelMatrix, "ModelMatrix");
    if(health ==2 )
    shader->SetTexture(texture_healthy, "Texture");
    else if(health == 1)
        shader->SetTexture(texture_halfHP, "Texture");
    mesh->Render();
}

// shared resources
MeshPtr Brick::mesh;
ShaderPtr Brick::shader;
TexturePtr Brick::texture_healthy;
TexturePtr Brick::texture_halfHP;